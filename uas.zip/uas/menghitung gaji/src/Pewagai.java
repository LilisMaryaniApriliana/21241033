public class Pewagai {
    public String nama;
    public String jabatan;
    public double pajak;
    private double gajipokok;
    private double gajibersih;

    public Pewagai(String nama, String jabatan, double pajak){
        this.nama = nama;
        this.jabatan = jabatan;
        this.pajak = pajak;
    }
    public void setgajipokok(double gajipokok){
        this.gajipokok = gajipokok;
    }
    public double gatgajibersih(){
        return gajibersih;
    }
    void Display(){
        gajibersih = (gajipokok*pajak) - gajipokok;
        System.out.println("Nama : " + nama);
        System.out.println("Jabatan : " + jabatan);
        System.out.println("Gaji bersih : " + gajibersih);
    }
    public static void main(String[] args) throws Exception {
        Pewagai pewagai = new Pewagai(adam, direktur, 5000)
        
    }
}
