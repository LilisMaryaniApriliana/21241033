public class App {

public class Lingkaran{
    public double phi;
    public double jari;
public Lingkaran(double phi, double jari){
    this.phi = phi;
    this.jari = jari;
}
public double jari(){
    return jari;
}
public double phi(){
    return phi;
}
public double hitungkeliling(){
     return (phi*jari*jari)
}
public double hitungluas(){
    return (2*phi*jari)
}
    public static void main(String[] args) throws Exception {
        Lingkaran lingkaran = new Lingkaran(3.14, 10);
        System.out.println("phi Lingkaran = ");
        System.out.println("jari-jari = ");
        System.out.println("Luas Lingkaran = ");
        System.out.println("Keliling lingkaran = ");
    }
}
